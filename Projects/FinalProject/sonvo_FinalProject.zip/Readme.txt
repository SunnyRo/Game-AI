###############################################
Task 1: Soduku solver using backtracking.
The program will read the data from input1.txt
How to run:
Type in terminal: python3 Task1.py or Run it using pycharm.
The program will print out the solved puzzle.
###############################################
Task 2: 0/1 knapsack Problem using best first serach with branch and bound
The program will read the data from input2.txt
How to run:
Type in terminal: python3 Task2.py or Run it using pycharm
The program will ask the user to input the capacity for knapsack (which should be 16 for the profit and weight in the input2.txt)
It will print out the max profit.
###############################################
Task 3: traveling salesman problem using best first search with branch and bound
The program will read the data from input3.txt
How to run:
Type in terminal python3 Task3.py or Run it using pycharm
The program will print out the optimal tour and its length.
