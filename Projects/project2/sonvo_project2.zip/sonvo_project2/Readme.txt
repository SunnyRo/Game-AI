#########################################################################
Task1.py
Run the code: type python3 Task1.py in terminal or using pycharm 
1/ The program will ask user to enter knapsack capacity
2/ Then ask user to enter weights of the items in order: eg 40 20 50
3/ Ask user to enter profits of the items in order: eg 50 20 40
so the first item will have weight = 40 and profit = 50
4/ The program will print out the maximum profit and List items that maximize the  profit
#########################################################################
Task2.py
Run the code: type python3 Task2.py in terminal or using pycharm 
1/ The program will ask user to enter knapsack capacity
2/ Then ask user to enter weights of the items in order: eg 40 20 50
3/ Ask user to enter profits of the items in order: eg 50 20 40
so the first item will have weight = 40 and profit = 50
4/ The program will print out the maximum profit and List items that maximize the  profit

#########################################################################
Task1.exe and Task2.exe are two executable files. These files need about 5-10s to run after 
opening the file so please wait a litle bit.
